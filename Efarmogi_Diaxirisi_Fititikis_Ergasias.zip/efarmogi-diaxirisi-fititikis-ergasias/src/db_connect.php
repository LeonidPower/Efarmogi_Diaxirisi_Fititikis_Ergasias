<?php
error_log("Connecting to database...");
try {
  $conn = mysqli_connect('localhost', 'yuriy', '', 'cut_edfe');

  $sql =
    "SELECT * 
       FROM system_configurations 
      WHERE id = 1";

  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $result = $stmt->get_result();

  // Maybe a bit of overkill, but with this implementation these values are always up to date
  $row = $result->fetch_assoc();
  $_SESSION['start_daytime'] = $row['start_daytime'];
  $_SESSION['end_daytime'] = $row['end_daytime'];
  $_SESSION['hourly_rate'] = $row['hourly_rate'];
  $_SESSION['annual_max_payout'] = $row['annual_max_payout'];

  $stmt->close();
  $conn->close();
  error_log("System Configurations loaded successfully.");
} catch (Exception $e) {
  header("Location: ../commons/oups.php");
  error_log("Connection failed: " . $e->getMessage());
}

$conn = mysqli_connect('localhost', 'user01', '', 'cut_edfe');

// Copyright (c) 2023 Yuriy Konyk

