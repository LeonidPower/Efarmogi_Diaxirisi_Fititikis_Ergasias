<?php
require 'check_login.php';
require 'mixins.php';
require 'db_connect.php';

if ($_POST['id']) {
    $id = validate($_POST['id']);
} else {
    include "../admin/employee.html";
    exit();
}

$stmt = $conn->prepare("DELETE FROM employees WHERE user_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

header("Location: employee.php");
