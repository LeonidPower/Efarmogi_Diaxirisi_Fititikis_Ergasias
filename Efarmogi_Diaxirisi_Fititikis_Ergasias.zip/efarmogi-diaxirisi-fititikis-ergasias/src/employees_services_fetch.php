<?php
            require "db_connect.php";
            require_once "objects.php";
            
            $query_get_services = "SELECT as_id, name FROM administrative_services;";
            $result = mysqli_query($conn, $query_get_services);

            
            $i = 1 ; 

            $services_list = array();
            $employees_list = array();

            if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)){
                    $service_obj = new Service($row['as_id'], $row['name']);
                    array_push($services_list, $service_obj);
                }
            }
            
            $query_get_employees = "SELECT employees.user_id as u_id, employees.name AS u_name, employees.surname AS u_surname, employees.email AS u_email, employees.phone as u_phone, 
            employees.address as u_address, employees.position_id AS p_id, employees.service_id AS as_id, position.name as p_name
            FROM employees
            JOIN administrative_services ON administrative_services.as_id = employees.service_id
            JOIN position ON position.position_id = employees.position_id;";

            $result = mysqli_query($conn, $query_get_employees);


            if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)){
                    $employee_obj = new Employee($row['u_id'], $row['u_name'], $row['u_surname'], $row['u_email'], $row['u_phone'], $row['u_address'], $row['as_id'] , $row['p_id']);
                    array_push($employees_list, $employee_obj);
                    
                }
            }
?>