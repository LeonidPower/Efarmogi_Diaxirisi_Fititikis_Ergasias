<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    echo var_dump($_POST);
    if ($_POST['id_delete']){   
        $id = validate($_POST['id_delete']);
    }
    else{
        echo "here";
        include "services.php";
        exit();
    }

    $sql= "DELETE FROM employees WHERE user_id = '$id';";
    $result = mysqli_query($conn, $sql);
    header("Location: services.php");
    
?>