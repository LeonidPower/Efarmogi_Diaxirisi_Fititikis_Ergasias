<?php
    function validate($data){
        return $data ? htmlspecialchars(stripslashes(trim($data))) : null;
    }
?>