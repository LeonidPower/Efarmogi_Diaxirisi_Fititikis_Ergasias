<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && $_POST['id']){   
        $id = validate($_POST['id']);
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);
    }
    else{
        include "services.php";
        exit();
    }


    $service = isset($_POST['service']) ? validate($_POST['service']) : null;
    $address = isset($_POST['address']) ? validate($_POST['address']) : "";
    $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";

    if(empty($firstname)){ 
      header("Location: services.php?error=firstname is empty");
      exit();
    }
    elseif(empty($lastname)){ 
        header("Location: services.php?error=lastname is empty");
        exit();
    }
    elseif(empty($email)){ 
        header("Location: services.php?error=email is empty");
        exit();
    }
    else{
        if(!empty($service)){
            $sql= "UPDATE employees 
            SET name = '$firstname', surname = '$lastname',
            phone = '$phone', address = '$address', email = '$email', 
            service_id = '$service'
            WHERE user_id = '$id';";

        }
        else{ 
            $sql= "UPDATE employees 
            SET name = '$firstname', surname = '$lastname',
            phone = '$phone', address = '$address', email = '$email', 
            WHERE user_id = '$id';";
        }
       
        $result = mysqli_query($conn, $sql); #we might need this later
        header("Location: services.php");
    }
?>