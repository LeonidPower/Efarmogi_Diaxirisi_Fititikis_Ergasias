<?php

session_start();

require "db_connect.php";
require "mixins.php";

error_log("Login attempt" . (isset($_SESSION['loggedin']) ? " Logged in" : " Not logged in"));

if (isset($_POST['email']) && isset($_POST['pass'])) {
    $email = validate($_POST['email']);
    $password = md5(validate($_POST['pass']));
} else {
    include  "../commons/login.php";
    exit();
}

if (empty($email) || empty($password)) {
    $_SESSION['error'] = "Email and Password are required";
    header("Location: ../commons/login.php");
    exit();
} else {
    try {
        $sql =
            "SELECT 
                    name,
                    surname,
                    email,
                    user_id,
                    position_id 
               FROM employees 
              WHERE email = ? 
                AND password = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        $conn->close();

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);
                session_start();
                $_SESSION['loggedin'] = True;
                $_SESSION['name']     = $row['name'];
                $_SESSION['surname']  = $row['surname'];
                $_SESSION['email']    = $row['email'];
                $_SESSION['user_id']  = $row['user_id'];
                $_SESSION['position'] = $row['position_id'];
                error_log("User logged: Name:[" 
                . $_SESSION['name'] 
                . "] Surname:[" 
                . $_SESSION['surname'] 
                . "] Email:[" 
                . $_SESSION['email'] 
                . "] UserID:[" 
                . $_SESSION['user_id'] 
                . "] Position:[" 
                . $_SESSION['position']
                . "]");
                header("Location: ../commons/dashboard.php");
                exit();
        } else {
            error_log("Unsuccessful login attempt: Email:[" . $email . "]");
            $_SESSION['error'] = "Email or Password is incorrect";
            header("Location: ../commons/login.php");
            exit();
        }
    } catch (Exception $e) {
        error_log("ERROR: [ " . $e->getMessage() ." ]");
        header("Location: ../commons/oups.php");
    }
}
