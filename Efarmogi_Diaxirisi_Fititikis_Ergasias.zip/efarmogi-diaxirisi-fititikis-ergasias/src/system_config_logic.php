<?php

$error_msg = "";
$flag_changed = false;

$current_start_daytime = isset($_SESSION['start_daytime']) ? $_SESSION['start_daytime'] : null;
$current_end_daytime = isset($_SESSION['end_daytime']) ? $_SESSION['end_daytime'] : null;

if (isset($_POST['start_daytime']) && $_POST['start_daytime'] != "") {
    if ($current_end_daytime && $_POST['start_daytime'] >= $current_end_daytime) {
        $error_msg[] = "Start Daytime must be greater than $current_end_daytime. ";
    } else {
        $_SESSION['start_daytime'] = $_POST['start_daytime'];
        $flag_changed = true;
        error_log("Start Daytime changed to: " . $_SESSION['start_daytime']);
    }
}

if (isset($_POST['end_daytime']) && $_POST['end_daytime'] != "") {
    if ($current_start_daytime && $_POST['end_daytime'] <= $current_start_daytime) {
        $error_msg[] = "End Daytime must be greater than $current_start_daytime. ";
    } else {
        $_SESSION['end_daytime'] = $_POST['end_daytime'];
        $flag_changed = true;
        error_log("End Daytime changed to: " . $_SESSION['end_daytime']);
    }
}


if (isset($_POST['hourly_rate']) && $_POST['hourly_rate'] != "") {
    if (is_numeric($_POST['hourly_rate'])) {
        $_SESSION['hourly_rate'] = $_POST['hourly_rate'];
        $flag_changed = true;
        error_log("Hourly Rate changed to: " . $_SESSION['hourly_rate']);
    } else {
        error_log("Hourly Rate must be a number");
        $error_msg[] = "Hourly Rate must be a number. ";
    }
}

if (isset($_POST['annual_max_payout']) && $_POST['annual_max_payout'] != "") {
    if (is_numeric($_POST['annual_max_payout'])) {
        $_SESSION['annual_max_payout'] = $_POST['annual_max_payout'];
        $flag_changed = true;
        error_log("Annual Max Payout changed to: " . $_SESSION['annual_max_payout']);
    } else {
        error_log("Annual Max Payout must be a number");
        $error_msg[] = "Annual Max Payout must be a number. ";
    }
}

if ($error_msg != "") {
    $_SESSION['error'] = $error_msg;
    header("Location: ../admin/sysconfigs.php");
    exit();
}

error_log("Start Daytime: "
    . (isset($_SESSION['start_daytime']) ? $_SESSION['start_daytime'] : "Not set")
    . " | End Daytime: "
    . (isset($_SESSION['end_daytime']) ? $_SESSION['end_daytime'] : "Not set")
    . " | Hourly Rate: "
    . (isset($_SESSION['hourly_rate']) ? $_SESSION['hourly_rate'] : "Not set")
    . " | Annual Max Payout: "
    . (isset($_SESSION['annual_max_payout']) ? $_SESSION['annual_max_payout'] : "Not set"));


if ($flag_changed) {
    $_SESSION['message'] = "System Configurations updated successfully.";
    try {
        require "db_connect.php";
        $sql =
            "UPDATE system_configurations 
                SET 
                    start_daytime = ?, 
                    end_daytime = ?, 
                    hourly_rate = ?, 
                    annual_max_payout = ? 
              WHERE id = 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ssdd",
            $_SESSION['start_daytime'],
            $_SESSION['end_daytime'],
            $_SESSION['hourly_rate'],
            $_SESSION['annual_max_payout']
        );
        $stmt->execute();
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        error_log("Error updating system configurations: " . $e->getMessage());
        $_SESSION['error'] = "Error updating system configurations: " . $e->getMessage();
        header("Location: ../admin/sysconfigs.php");
        exit();
    }
}
header("Location: ../commons/dashboard.php");

// # /* =comment <!-- Copyright (c) 2023 Yuriy Konyk XD --> */ =cut