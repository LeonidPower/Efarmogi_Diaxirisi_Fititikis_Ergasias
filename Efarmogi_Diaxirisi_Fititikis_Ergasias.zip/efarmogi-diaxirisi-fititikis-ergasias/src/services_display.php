<?php
            require "db_connect.php";
            require_once "objects.php";
            require_once "employees_services_fetch.php";
            
            foreach($services_list as $s){
                echo "<div class='table-size-1 mt-4'>
                            <table id='table-$i' class='table-size-1 cell-border hover'>
                            <thead>
                                <tr>";
                echo "                <th colspan='9' class='text-center h3'>" . htmlspecialchars($s->service_name) . "</th>";
                echo "          </tr>
                                <tr>
                                    <th>Edit</th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Surname</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>

                                </tr>
                            </thead>
                            <tbody>";
                            
                            
                            foreach($employees_list as $e){
                                if($e->employee_service == $i && $e->employee_position == '1'){
                                    echo "<tr>";
                                    echo "<td><input class='form-check-input' type='radio' name='employee_select' id='employee_select'></td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_id) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_name) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_surname). "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_email) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_phone) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($e->employee_address) . "</td>";
                                    echo "</tr>";
                                }
                            }
                                 
                            
                        echo    "</tbody>
                        </table>
                        <button  id='edit_btn_$i' type='button' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#edit_employee_services' disabled>
                                Edit
                        </button>
                        <form class='d-inline ms-2' method='POST' action='../src/delete_services_employee.php' novalidate>
                            <input name='id_delete' id='inputID_all_delete_$i' required hidden/>
                            <button  id='delete_btn_$i' type='submit' class='btn btn-danger' disabled>
                                Delete
                            </button>
                        </form>
                    </div>";
                    $i++;
            }
            
        ?>
