<?php
    require 'check_login.php';
    require 'mixins.php';
    require 'db_connect.php';

    if (isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email']) && $_POST['id']){   
        $id = validate($_POST['id']);
        $firstname = validate($_POST['first_name']);
        $lastname = validate($_POST['last_name']);
        $email = validate($_POST['email']);
    }
    else{
        include "../admin/employee.html";
        exit();
    }

    $address = isset($_POST['address']) ? validate($_POST['address']) : "";
    $phone = isset($_POST['phone']) ? validate($_POST['phone']) : "";
    $position = isset($_POST['position']) ? validate($_POST['position']) : "";

    $errorMessages = [];

    if (empty($firstname)) {
        $errorMessages[] = "First name";
    }
    if (empty($lastname)) {
        $errorMessages[] = "Last name";
    }
    if (empty($email)) {
        $errorMessages[] = "Email";
    }

    if (!empty($errorMessages)) {
        $errorMessage = implode(", ", $errorMessages) . " is empty";
        header("Location: employee_form.php?error=$errorMessage");
        exit();
    }
    else{

        try {
        $sql = 
        "UPDATE employees 
            SET name = ?, 
                surname = ?,
                phone = ?, 
                address = ?,
                email = ?
          WHERE user_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $firstname, $lastname, $phone, $address, $email, $id);
        $stmt->execute();
        $stmt->close();
        } catch (Exception $e) {
            error_log($e->getMessage());
            header ("Location: ../commons/oups.php");
        }

        header("Location: employee.php");
    }
?>