<?php

class Employee{
    public $employee_id;
    public $employee_name;
    public $employee_surname;
    public $employee_email;
    public $employee_phone;
    public $employee_address;
    public $employee_service;
    public $employee_position;

    function __construct($e_id, $e_name, $e_surname, $e_email, $e_address, $e_phone, $e_service, $e_position) {
        $this->employee_id = $e_id;
        $this->employee_name = $e_name;
        $this->employee_surname = $e_surname;
        $this->employee_email = $e_email;
        $this->employee_address = $e_address;
        $this->employee_phone = $e_phone;
        $this->employee_service = $e_service;
        $this->employee_position = $e_position;
    }
}

class Service{ 
    public $service_id;
    public $service_name;

    function __construct($s_id, $s_name){ 
        $this->service_id = $s_id;
        $this->service_name = $s_name;
        
    }
}

?>

