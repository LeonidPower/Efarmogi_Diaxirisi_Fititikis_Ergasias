<?php
require '../src/check_login.php';
require '../src/mixins.php';
require '../src/db_connect.php';

$requiredFields = ['first_name', 'last_name', 'email', 'position', 'service', 'pass', 'password_confirm'];

if (count(array_intersect($requiredFields, array_keys($_POST))) === count($requiredFields)) {

    $firstname        = validate($_POST['first_name']);
    $lastname         = validate($_POST['last_name']);
    $email            = validate($_POST['email']);
    $password         = validate(md5($_POST['pass']));
    $password_confirm = validate(md5($_POST['password_confirm']));
    $position         = validate($_POST['position']);
    $service          = validate($_POST['service']);
} else {

    include "../admin/employee_form.html";
    exit();
}

$address = isset($_POST['address']) ? validate($_POST['address']) : "";
$phone   = isset($_POST['phone']) ? validate($_POST['phone']) : "";

$errorMessages = [];

if (empty($firstname)) {
    $errorMessages[] = "First name";
}
if (empty($lastname)) {
    $errorMessages[] = "Last name";
}
if (empty($email)) {
    $errorMessages[] = "Email";
}
if (empty($password)) {
    $errorMessages[] = "Password ";
}
if (empty($password_confirm)) {
    $errorMessages[] = "Password confirmation";
}
if (empty($position)) {
    $errorMessages[] = "Position";
}
if (empty($service)) {
    $errorMessages[] = "Service";
}

if (!empty($errorMessages)) {
    $errorMessage = implode(", ", $errorMessages) . " is empty";
    header("Location: employee_form.php?error=$errorMessage");
    exit();
} else {

    $sql = "SELECT * 
              FROM employees 
             WHERE email = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if (!mysqli_num_rows($result)) {
        if ($password === $password_confirm) {

            $sql = "INSERT 
                      INTO employees (
                           name, 
                           surname, 
                           password, 
                           phone, 
                           address, 
                           email, 
                           position_id, 
                           service_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssii", $firstname, $lastname, $password, $phone, $address, $email, $position, $service);
            $stmt->execute();
            $stmt->close();
            header("Location: employee_form.php?success=1");
        } else {
            header("Location: employee_form.php?error=passwords don't match");
            exit();
        }
    } else {
        header("Location: employee_form.php?error=This email is already being used");
        exit();
    }
}
