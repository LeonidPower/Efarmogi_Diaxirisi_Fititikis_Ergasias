<?php
require '../src/check_login.php';
require 'check_permissions.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link href="../assets/datatables/datatables.css" rel="stylesheet" />
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
    <title>Employees -</title>
</head>
<?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->

<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class="inline"><i class="fas fa-user fa-fw me-1 inline"></i>Services</h1>
                <div class="table-size-1 mt-4">
                    <table id="employees-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <th colspan='9' class='text-center h3'>Όλοι Υπαλλήλοι</th>
                            </tr>
                            <tr>
                                <th>Edit</th>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Position</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require "../src/db_connect.php";

                            // TODO change that.
                            $query = "SELECT employees.user_id as u_id, employees.name AS u_name, employees.surname AS u_surname, employees.email AS u_email, employees.phone as u_phone, 
                            employees.address as u_address, employees.position_id AS p_id, position.name AS p_name, employees.service_id as s_id
                            FROM employees
                            JOIN position ON position.position_id = employees.position_id;";
                            $result = mysqli_query($conn, $query);
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td><input class='form-check-input' type='radio' name='employee_select' id='employee_select'></td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_id']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_name']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_surname']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_email']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_phone']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['u_address']) . "</td>";
                                    echo "<td class='clickable-row'>" . htmlspecialchars($row['p_name']) . "</td>";
                                    echo "</tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                    <button id="edit_employee_btn_all" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#edit_employee_position" disabled>
                        Edit
                    </button>
                    <form class="d-inline ms-2" method="POST" action="../src/delete_services_employee.php" novalidate>
                        <input name="id_delete" id="inputID_all_delete" required hidden />
                        <button id="delete_employee_btn_all" type="submit" class="btn btn-danger" disabled>
                            Delete
                        </button>
                    </form>
                    <div class="modal fade" id="edit_employee_position" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form id="form_all" method="POST" action="../src/update_position_employee.php" novalidate>
                                    <div class="modal-body">
                                        <?php
                                        if (isset($_GET['error'])) {
                                            echo '<p class="p-error">' . $_GET['error'] . '</p>';
                                        }
                                        ?>
                                        <div class="row mb-3">
                                            <input name="id" id="inputID_all_edit" required hidden />
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="first_name" id="inputFirstName_all" type="text" placeholder="Enter your first name" required />
                                                    <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="last_name" id="inputLastName_all" type="text" placeholder="Enter your last name" required />
                                                    <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail_all" type="email" placeholder="name@example.com" onblur="validateEmail()" required />
                                            <label for="inputEmail">Email Address <span class="required-field">*</span></label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="phone" id="inputPhoneNumber_all" type="tel" placeholder="Phone Number" />
                                                    <label for="inputPhoneNumber">Phone Number</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="address" id="inputAddress_all" type="text" placeholder="Address" />
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <?php
                                                    require_once '../src/db_connect.php';

                                                    $sql = "SELECT name,position_id FROM position;";
                                                    $result = mysqli_query($conn, $sql);

                                                    if (mysqli_num_rows($result) > 0) {
                                                        echo '<select class=""  id="select-position" name="position" autocomplete="off" placeholder="Position">
                                                                        <option disabled selected value></option>';

                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            echo '<option value="' . $row['position_id'] . '">' .  $row['name'] . '</option>';
                                                        }
                                                        echo '</select>';
                                                    }

                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>



                    <div class="modal fade" id="edit_employee_services" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form id="form_all" method="POST" action="../src/update_service_employee.php" novalidate>
                                    <div class="modal-body">
                                        <?php
                                        if (isset($_GET['error'])) {
                                            echo '<p class="p-error">' . $_GET['error'] . '</p>';
                                        }
                                        ?>
                                        <div class="row mb-3">
                                            <input name="id" id="inputID_all_edit" required hidden />
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="first_name" id="inputFirstName_all" type="text" placeholder="Enter your first name" required />
                                                    <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="last_name" id="inputLastName_all" type="text" placeholder="Enter your last name" required />
                                                    <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail_all" type="email" placeholder="name@example.com" onblur="validateEmail()" required />
                                            <label for="inputEmail">Email Address <span class="required-field">*</span></label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="phone" id="inputPhoneNumber_all" type="tel" placeholder="Phone Number" />
                                                    <label for="inputPhoneNumber">Phone Number</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="address" id="inputAddress_all" type="text" placeholder="Address" />
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating ms-3 mbmd-0" style="margin-bottom: 100pt;">
                                                    <?php
                                                    require_once '../src/db_connect.php';

                                                    $sql = "SELECT name,as_id FROM administrative_services;";
                                                    $result = mysqli_query($conn, $sql);

                                                    if (mysqli_num_rows($result) > 0) {
                                                        echo '<select class="mb-5"  id="select-service" name="service" autocomplete="off" placeholder="Services">
                                                                        <option disabled selected value></option>';

                                                        while ($row = mysqli_fetch_assoc($result)) {
                                                            echo '<option value="' . $row['as_id'] . '">' .  $row['name'] . '</option>';
                                                        }
                                                        echo '</select>';
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>



                </div>
                <!-- ----------------------------------------------------------------------------------SERVICES--------------------------------------------------------------------------------- -->
                <?php include "../src/services_display.php"; ?>

            </div>
        </main>
    </div>
    <!-- --------------------------------------- End --------------------------------------- -->
    <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
    <script src="../assets/datatables/datatables.js"></script>
    <script src="../assets/js/services.js"></script>
    <script>
        $(document).ready(function() {
            $('#employees-table').DataTable();
        });
    </script>

    <?php
    $i = 1;
    foreach ($services_list as $s) {

        echo " 
        <script>
            $(document).ready(function () {
            $('#table-$i').DataTable();
            });
        </script>";

        $i++;
    }
    ?>

</html>