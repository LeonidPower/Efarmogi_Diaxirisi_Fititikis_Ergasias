<?php
require '../src/check_login.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link href="../assets/datatables/datatables.css" rel="stylesheet" />
    <title>Employees -</title>
</head>
<?php include '../commons/base.php' ?>
<!-- --------------------------------------- Content --------------------------------------- -->

<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class="inline"><i class="fas fa-user fa-fw me-1 inline"></i>Employees</h1>
                <div class="table-size-1 mt-4">
                    <table id="employees-table" class="table-size-1 cell-border hover">
                        <thead>
                            <tr>
                                <th>Edit</th>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Surname</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require "../src/db_connect.php";

                            $query = "SELECT employees.user_id as u_id, employees.name AS u_name, employees.surname AS u_surname, employees.email AS u_email, employees.phone as u_phone, 
                                employees.address as u_address, employees.position_id AS p_id, position.name AS p_name
                                FROM employees
                                JOIN position ON position.position_id = employees.position_id;";
                            $result = mysqli_query($conn, $query);
                            $is_admin_array = array('1' => 'Admin', '0' => 'User');
                            $i = 0;
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    if ($row['p_id'] === '1') {
                                        echo "<tr>";
                                        echo "<td><input class='form-check-input' type='radio' name='employee_select' id='employee_select'></td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_id']) . "</td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_name']) . "</td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_surname']) . "</td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_email']) . "</td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_phone']) . "</td>";
                                        echo "<td class='clickable-row'>" . htmlspecialchars($row['u_address']) . "</td>";
                                        echo "</tr>";
                                        $i++;
                                    }
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                    <button id="edit_employee_btn" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#edit_employee" disabled>
                        Edit
                    </button>
                    <form class="d-inline ms-2" id="register_form" method="POST" action="../src/delete_employee.php">
                        <input name="id" id="inputID" required hidden />
                        <button id="delete_employee_btn" type="submit" class="btn btn-danger" disabled>
                            Delete
                        </button>
                    </form>
                    <div class="modal fade" id="edit_employee" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form id="register_form" method="POST" action="../src/update_employee.php">
                                    <div class="modal-body">
                                        <?php
                                        if (isset($_GET['error'])) {
                                            echo '<p class="p-error">' . $_GET['error'] . '</p>';
                                        }
                                        ?>
                                        <div class="row mb-3">
                                            <input name="id" id="inputID" required hidden />
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="first_name" id="inputFirstName" type="text" placeholder="Enter your first name" required />
                                                    <label for="inputFirstName">First Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="last_name" id="inputLastName" type="text" placeholder="Enter your last name" required />
                                                    <label for="inputLastName">Last Name <span class="required-field">*</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" onblur="validateEmail()" required />
                                            <label for="inputEmail">Email Address <span class="required-field">*</span></label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="phone" id="inputPhoneNumber" type="tel" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="Phone Number" />
                                                    <label for="inputPhoneNumber">Phone Number</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address" />
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <!-- --------------------------------------- End --------------------------------------- -->
    <script src="../assets/datatables/datatables.js"></script>
    <script src="../assets/js/employees.js"></script>
    <script>
        $(document).ready(function() {
            $('#employees-table').DataTable();
        });
    </script>

</html>
?>