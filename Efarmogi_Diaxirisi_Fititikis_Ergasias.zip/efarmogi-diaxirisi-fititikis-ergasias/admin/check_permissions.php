<?php
// Check if postion is admin
if ($_SESSION['position'] != '3') {
    $_SESSION['error'] = "You have insufficient permissions to access certain pages. If you believe this is an error, please contact your administrator.";
    header("Location: ../commons/oups.php");
    exit();
}

// Reminder by Yuriy: Mine bitcoin here