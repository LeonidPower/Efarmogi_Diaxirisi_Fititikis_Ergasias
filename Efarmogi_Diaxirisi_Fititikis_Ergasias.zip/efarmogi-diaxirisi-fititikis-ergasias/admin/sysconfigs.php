<?php
require '../src/check_login.php';
require 'check_permissions.php';

?>


<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>System Configuration</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
    <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>


</head>

<!-- --------------------------------------- Content --------------------------------------- -->

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container ">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5" style="height: 100%;">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">System Configuration</h3>
                                </div>
                                <div class="card-body">
                                    <form id="config_form" style="overflow: hidden;" method="POST" action="../src/system_config_logic.php">
                                        <?php
                                        if (isset($_SESSION['error'])) {
                                            echo '<div class="alert alert-danger" role="alert">';
                                            foreach ($_SESSION['error'] as $error) {
                                                echo $error;
                                            }
                                            echo '</div>';
                                            unset($_SESSION['error']);
                                        }
                                        ?>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="h4">System Hours</label>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="start_daytime" id="inputStartDayTime" type="time"/>
                                                    <label for="inputStartDayTime">Start Time</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="end_daytime" id="inputEndDayTime" type="time" />
                                                    <label for="inputEndDayTime">End Time</label>
                                                </div>
                                            </div>
                                        </div>

                                        <hr>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label class="h4">System Variables</label>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-3">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="hourly_rate" id="inputHourlyRate" type="number" step="0.1" />
                                                    <label for="inputHourlyRate">Hourly Rate</label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="annual_max_payout" id="inputAnnualMaxPayout" type="number" step="100" />
                                                    <label for="inputAnnualMaxPayout">Annual Max Payout</label>
                                                </div>
                                            </div>

                                            <div class="mt-4 mb-0 overflow-vissible">
                                                <button class="btn btn-primary btn-block" type="submit" id="save-button">Save</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!-- <div class="card-footer text-center py-3">
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>

</html>

<!-- Copyright (c) 2023 Yuriy Konyk XD -->