<?php
require_once '../src/db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Register - Cyprus University of Technology</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <link href="../node_modules/tom-select/dist/css/tom-select.bootstrap4.css" rel="stylesheet" />
    <link href="../assets/css/tom-select-style.css" rel="stylesheet" />
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container ">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5" style="height: 100%;">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Create Employee Account</h3>
                                </div>
                                <div class="card-body">
                                    <a href="../commons/dashboard.php"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                                    <form id="register_form" style="overflow: hidden;" method="POST" action="../admin/employee_checks.php">
                                        <?php
                                        if (isset($_GET['error'])) {
                                            echo '<p class="p-error">' . $_GET['error'] . '</p>';
                                        } elseif (isset($_GET['success'])) {
                                            echo '<p class="p-success">Employee added succesfully</p>';
                                        }
                                        ?>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="first_name" id="inputFirstName" type="text" placeholder="Enter your first name" required />
                                                    <label for="inputFirstName">First Name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" name="last_name" id="inputLastName" type="text" placeholder="Enter your last name" required />
                                                    <label for="inputLastName">Last Name</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" name="email" id="inputEmail" type="email" placeholder="name@example.com" required />
                                            <label for="inputEmail">Email Address</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="pass" id="inputPassword" type="password" placeholder="Create a password" required />
                                                    <label for="inputPassword">Password</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" name="password_confirm" id="inputPasswordConfirm" type="password" placeholder="Confirm password" required />
                                                    <label for="inputPasswordConfirm">Confirm Password</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="address" id="inputAddress" type="text" placeholder="Address" />
                                                    <label for="inputAddress">Address</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mbmd-0">
                                                    <input class="form-control" name="phone" id="inputPhone" type="tel" placeholder="Phone Number" />
                                                    <label for="inputAddress">Phone</label>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mbmd-0">
                                                        <?php

                                                        $sql = "SELECT name,
                                                                       position_id 
                                                                  FROM position;";
                                                        
                                                        $result = null;
                                                        try {
                                                            $result = mysqli_query($conn, $sql);
                                                        } catch (Exception $e) {
                                                            error_log($e->getMessage());
                                                            echo '<p class="p-error">Temporary error, please try again later.</p>';
                                                        }

                                                        if ($result && mysqli_num_rows($result) > 0) {
                                                            echo '<select class="" id="select-position" name="position" autocomplete="off" placeholder="Position" required>
                                                                    <option disabled selected value></option>';

                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                echo '<option value="' . $row['position_id'] . '">' .  $row['name'] . '</option>';
                                                            }
                                                            echo '</select>';
                                                        }

                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating ms-3 mbmd-0" style="margin-bottom: 100pt;">
                                                        <?php

                                                        $sql = "SELECT name,
                                                                       as_id 
                                                                  FROM administrative_services;";
                                                        
                                                        $result = null;
                                                        try {
                                                            $result = mysqli_query($conn, $sql);
                                                        } catch (Exception $e) {
                                                            error_log($e->getMessage());
                                                            echo '<p class="p-error">Temporary error, please try again later.</p>';
                                                        }

                                                        if ($result && mysqli_num_rows($result) > 0) {
                                                            echo '<select class="mb-5"  id="select-service" name="service" autocomplete="off" placeholder="Services" required>
                                                                    <option disabled selected value></option>';

                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                echo '<option value="' . $row['as_id'] . '">' .  $row['name'] . '</option>';
                                                            }
                                                            echo '</select>';
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-4 mb-0 overflow-vissible">
                                            <button class="btn btn-primary btn-block" type="submit" id="register_button">Register Employee</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="../node_modules/tom-select/dist/js/tom-select.complete.js"></script>
    <script src="../assets/js/employee_register.js"></script>
</body>

</html>