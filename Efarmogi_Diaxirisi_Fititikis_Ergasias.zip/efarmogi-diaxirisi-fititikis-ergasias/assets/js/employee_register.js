const inputPassword = document.getElementById('inputPassword');
const inputPasswordConfirm = document.getElementById('inputPasswordConfirm');

inputPasswordConfirm.addEventListener('input', () => {
  if (inputPassword.value !== inputPasswordConfirm.value) {
    inputPasswordConfirm.setCustomValidity('Passwords do not match');
  } else {
    inputPasswordConfirm.setCustomValidity('');
  }
});

inputPassword.addEventListener('input', () => {
  inputPasswordConfirm.setCustomValidity('');
});

document.querySelector('form').addEventListener('submit', (event) => {
  if (inputPassword.value !== inputPasswordConfirm.value) {
    event.preventDefault();
    inputPasswordConfirm.setCustomValidity('Passwords do not match');
  }
});

new TomSelect('#select-position',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});


new TomSelect('#select-service',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});

