const table = document.getElementById("employees-table");
const radios = table.querySelectorAll("input[type='radio']");

radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            

            const edit_btn = $('#delete_employee_btn_all');
            const delete_btn =  $('#edit_employee_btn_all');

            $(edit_btn).removeAttr('disabled');
            $(delete_btn).removeAttr('disabled');

            for (var j = 1 ; j<tables_num; j++){ 
                        
            const edit_btn_prop = document.getElementById(`edit_btn_${j}`);
            const delete_btn_prop = document.getElementById(`delete_btn_${j}`);

            if(edit_btn !== edit_btn_prop && delete_btn !== delete_btn_prop){
                $(edit_btn_prop).prop('disabled', true);
                $(delete_btn_prop).prop ('disabled', true);

            }
        }
            checkedRow = radio.closest("tr");
        }
    })
});

$('#edit_employee_btn_all').click(()=>{ 
    if (checkedRow) {
        const id = checkedRow.querySelector("td:nth-child(2)").textContent;
        const name = checkedRow.querySelector("td:nth-child(3)").textContent;
        const surname = checkedRow.querySelector("td:nth-child(4)").textContent;
        const email = checkedRow.querySelector("td:nth-child(5)").textContent;
        const phone = checkedRow.querySelector("td:nth-child(6)").textContent;
        const address = checkedRow.querySelector("td:nth-child(7)").textContent;

        $("#inputID_all_edit").val(id);
        $("#inputFirstName_all").val(name);
        $("#inputLastName_all").val(surname);
        $("#inputEmail_all").val(email);
        $("#inputPhoneNumber_all").val(phone);
        $("#inputAddress_all").val(address);

    } 
})

$('#delete_employee_btn_all').click(()=>{ 
    const id = checkedRow.querySelector("td:nth-child(2)").textContent;
    $("#inputID_all_delete").val(id);

})




var tables = document.getElementsByTagName('table');
var tables_num = tables.length;

for (var i=1; i<tables_num; i++){
    const table = document.getElementById(`table-${i}`);
    const edit_btn = document.getElementById(`edit_btn_${i}`);
    const id_input = document.getElementById(`inputID_all_delete_${i}`);
    const delete_btn = document.getElementById(`delete_btn_${i}`);
    const radios = table.querySelectorAll("input[type='radio']");

    radios.forEach(radio => {

        radio.addEventListener('change', ()=>{
           

                $(edit_btn).removeAttr('disabled');
                $(delete_btn).removeAttr('disabled');

                $("#edit_employee_btn_all").prop('disabled', true);
                $("#delete_employee_btn_all").prop ('disabled', true);
            
                for (var j = 1 ; j<tables_num; j++){ 
                        
                        const edit_btn_prop = document.getElementById(`edit_btn_${j}`);
                        const delete_btn_prop = document.getElementById(`delete_btn_${j}`);

                        if(edit_btn !== edit_btn_prop && delete_btn !== delete_btn_prop){
                            $(edit_btn_prop).prop('disabled', true);
                            $(delete_btn_prop).prop ('disabled', true);

                        }
                }
                
                checkedRow = radio.closest("tr");
            
        })
    });

    $(edit_btn).click(()=>{ 
            const id = checkedRow.querySelector("td:nth-child(2)").textContent;
            const name = checkedRow.querySelector("td:nth-child(3)").textContent;
            const surname = checkedRow.querySelector("td:nth-child(4)").textContent;
            const email = checkedRow.querySelector("td:nth-child(5)").textContent;
            const phone = checkedRow.querySelector("td:nth-child(6)").textContent;
            const address = checkedRow.querySelector("td:nth-child(7)").textContent;

            $(`#inputID_all_edit`).val(id);
            $(`#inputFirstName_all`).val(name);
            $(`#inputLastName_all`).val(surname);
            $(`#inputEmail_all`).val(email);
            $(`#inputPhoneNumber_all`).val(phone);
            $(`#inputAddress_all`).val(address);
    
    })
    
    $(delete_btn).click(()=>{ 
        const id = checkedRow.querySelector("td:nth-child(2)").textContent;
        $(id_input).val(id);
    
    })
}



new TomSelect('#select-position',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});

new TomSelect('#select-service',{
	create: false,
	sortField: {
		field: 'text',
		direction: 'asc'
	}
});