function setCookie(name, value, days) {
    var expires = "";
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
  }

  // Function to get a cookie value
  function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1, c.length);
      }
      if (c.indexOf(nameEQ) == 0) {
        return c.substring(nameEQ.length, c.length);
      }
    }
    return null;
  }

  // Function to handle checkbox state change
  function handleCheckboxChange() {
    var checkbox = document.getElementById("inputRememberPassword");

    // Check if the checkbox is checked
    if (checkbox.checked) {
      // Store the preference in a cookie for 30 days
      setCookie("rememberPassword", "true", 30);
      console.log("Remember password is checked.");
    } else {
      // Remove the preference cookie
      setCookie("rememberPassword", "", -1);
      console.log("Remember password is not checked.");
    }
  }

  // Function to check the stored preference on page load
  function checkRememberPassword() {
    var rememberPassword = getCookie("rememberPassword");

    if (rememberPassword === "true") {
      document.getElementById("inputRememberPassword").checked = true;
    }
  }