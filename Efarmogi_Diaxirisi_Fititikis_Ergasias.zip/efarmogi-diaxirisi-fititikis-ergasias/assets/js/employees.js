const table = document.getElementById("employees-table");
const radios = table.querySelectorAll("input[type='radio']");

var checked_radio;
radios.forEach(radio => {
  radio.addEventListener('change', ()=>{
        if (radio.checked){
            $('#edit_employee_btn').removeAttr('disabled');
            $('#delete_employee_btn').removeAttr('disabled');

            checked_radio = radio;
            checkedRow = radio.closest("tr");
        }
        else{ 
            $('#delete_employee_btn').prop('disabled');
            $('#edit_employee_btn').prop('disabled')
        }

    })
});

$('#edit_employee_btn').click(()=>{ 
    if (checkedRow) {
        const id = checkedRow.querySelector("td:nth-child(2)").textContent;
        const name = checkedRow.querySelector("td:nth-child(3)").textContent;
        const surname = checkedRow.querySelector("td:nth-child(4)").textContent;
        const email = checkedRow.querySelector("td:nth-child(5)").textContent;
        const phone = checkedRow.querySelector("td:nth-child(6)").textContent;
        const address = checkedRow.querySelector("td:nth-child(7)").textContent;

        $("#inputID").val(id);
        $("#inputFirstName").val(name);
        $("#inputLastName").val(surname);
        $("#inputEmail").val(email);
        $("#inputPhoneNumber").val(phone);
        $("#inputAddress").val(address);

    } else {
        console.log("No radio button is checked.");
    }
})

$('#delete_employee_btn').click(()=>{ 
    const id = checkedRow.querySelector("td:nth-child(2)").textContent;
    $("#inputID").val(id);

})

