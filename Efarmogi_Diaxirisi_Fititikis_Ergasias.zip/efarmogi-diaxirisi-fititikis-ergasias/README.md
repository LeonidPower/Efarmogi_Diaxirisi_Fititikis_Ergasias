#### Team Number 5

| Team Members          | Email                           | IDs   |
|-----------------------|---------------------------------|-------|
| Giorgos Pantazopoulos |                                 | xxxxx |
| Rafael Neocleous      | rn.neokleous@edu.cut.ac.cy      | 19858 |
| Leonidas Ttofari      | lm.ttofari@edu.cut.ac.cy        | 19649 |
| Yuri Konik            | yi.konyk@edu.cut.ac.cy          | 17680 |
| Iacovos Kontopyrgos   | im.kontopyrgos@edu.cut.ac.cy    | 22227 |


#### Description

This project focuses on creating a website with user management functionality. The website allows the creation of new users and the assignment of services and positions to them. The services available are based on the eight services listed on CUT's website, while the positions include Student, Service Admin, and Admin.

#### Functionality

The website provides the following functionality:

- Creation of new users and assignment of services and positions.
- Display of all services, along with student employees, in a table.
- Display of all users in the first table.

#### Database

The latest push includes a copy of the latest database used for this project.
