-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 07, 2023 at 12:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cut_edfe`
--
CREATE DATABASE IF NOT EXISTS `cut_edfe` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cut_edfe`;

-- --------------------------------------------------------

--
-- Table structure for table `administrative_services`
--

CREATE TABLE `administrative_services` (
  `as_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `administrative_services`:
--

--
-- Dumping data for table `administrative_services`
--

INSERT INTO `administrative_services` (`as_id`, `name`) VALUES
(1, 'Υπηρεσία Ανθρώπινου Δυναμικού'),
(2, 'Υπηρεσία Διαχείρισης Περιουσίας'),
(3, 'Υπηρεσία Έρευνας'),
(4, 'Υπηρεσία Οικονομικών'),
(5, 'Υπηρεσία Συστημάτων Πληροφορικής και Τεχνολογίας'),
(6, 'Βιβλιοθήκη'),
(7, 'Υπηρεσία Σπουδών και Φοιτητικής Ευημερίας'),
(8, 'Υπηρεσία Επικοινωνίας, Προώθησης και Διεθνοποίησης');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `user_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(13) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `position_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `employees`:
--   `position_id`
--       `position` -> `position_id`
--   `service_id`
--       `administrative_services` -> `as_id`
--

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`user_id`, `name`, `surname`, `password`, `phone`, `address`, `email`, `position_id`, `service_id`) VALUES
(54, 'Rafael', 'Neokleous', '202cb962ac59075b964b07152d234b70', '', '', 'rafailmaximos@hotmail.com', 3, 8),
(55, 'Rafael', 'Neocleous', '202cb962ac59075b964b07152d234b70', '', '', 'qwerqew@qre.com', 3, 8);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `position_id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `position`:
--

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`position_id`, `name`, `description`) VALUES
(1, 'Student Employee\r\n', ''),
(2, 'Administrative service management\r\n', ''),
(3, 'Admin\r\n', '');

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

CREATE TABLE `resetpassword` (
  `Id` int(11) NOT NULL,
  `Email` text NOT NULL,
  `Selector` text NOT NULL,
  `Token` longtext NOT NULL,
  `Expires` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `resetpassword`:
--

--
-- Dumping data for table `resetpassword`
--

INSERT INTO `resetpassword` (`Id`, `Email`, `Selector`, `Token`, `Expires`) VALUES
(32, 'rafailmaximos@hotmail.com', '797094623fce0970', 'e9f29f1c9b81abbd776a701fad190475d64a2a57f85b5a2b9af0fde95050b60d', '1679152243');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrative_services`
--
ALTER TABLE `administrative_services`
  ADD PRIMARY KEY (`as_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `position_fk` (`position_id`),
  ADD KEY `service_fk` (`service_id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `resetpassword`
--
ALTER TABLE `resetpassword`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrative_services`
--
ALTER TABLE `administrative_services`
  MODIFY `as_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `resetpassword`
--
ALTER TABLE `resetpassword`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `position_fk` FOREIGN KEY (`position_id`) REFERENCES `position` (`position_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `service_fk` FOREIGN KEY (`service_id`) REFERENCES `administrative_services` (`as_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

CREATE TABLE system_configurations (
  id INT PRIMARY KEY,
  start_daytime TIME,
  end_daytime TIME,
  hourly_rate DECIMAL(10, 2),
  annual_max_payout DECIMAL(10, 2)
);

INSERT INTO system_configurations (id, start_daytime, end_daytime, hourly_rate, annual_max_payout) VALUES (1, '08:00:00', '16:00:00', 5.00, 1000.00);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
