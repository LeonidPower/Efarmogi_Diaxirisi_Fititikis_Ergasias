<!DOCTYPE html>
<html>

<head>
    <title>Oops, Something Went Wrong</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }

        .error-container {
            text-align: center;
        }

        .error-message {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .error-description {
            font-size: 16px;
            color: #666;
        }
    </style>
</head>

<body>
    <div class="error-container">
        <?php
        session_start();
        if (isset($_SESSION['message'])) {
            echo '<div class="alert alert-danger" role="alert">' . $_SESSION['message'] . '</div>';
            unset($_SESSION['message']);
        }
        ?>
        <h1 class="error-message">
            Congrats, you broke it!</h1>
        <p class="error-description">We are shocked as you are, but don't worry we will fix everything for you soon</p>
        <style>
            button__link {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                color: aquamarine;
            }
        </style>
        <a href="login.php">
            <button class="button__link">Go back</button>
        </a>
    </div>
</body>

</html>