<?php
require '../src/check_login.php';
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../commons/base.php' ?>

<head>
    <link href="../assets/css/dashboard.css" rel="stylesheet" />
    <title>Dashboard - Cyprus University of technology</title>
</head>
<!-- --------------------------------------- Content --------------------------------------- -->

<body>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4 mt-5 ms-4">
                <h1 class="">Here could be your ad</h1>
            </div>
        </main>
    </div>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script> -->
    <!-- <script src="assets/demo/chart-area-demo.js"></script> -->
    <!-- <script src="assets/demo/chart-bar-demo.js"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script> -->
    <!-- <script src="js/datatables-simple-demo.js"></script> -->
</body>

</html>