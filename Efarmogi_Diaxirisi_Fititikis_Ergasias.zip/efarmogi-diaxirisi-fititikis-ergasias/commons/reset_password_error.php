<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Reset Password - Cyprus University of Technology</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="row justify-content-center">
                            <img src="../assets/img/logo.png" alt="Logo of the company"
                                style="width: 250px; height: 100px;">
                        </div>
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4"> <main><?php echo base64_decode($_GET["error"]) ?></main></h3>
                                </div>
                                <div class="card-body">
                                    <div class="wrapper-main">
                                        <p class="display-8-5 text-center d-inline"><?php echo base64_decode($_GET["error_description"]); ?>
                                    Press </p>
                                        <p class="fw-bold d-inline text-center">OK</p> 
                                        <p class="display-8-5 text-center d-inline">to go back to the login page.</p>
                                        <a class="btn btn-primary float-end mt-5" href="login.php">OK</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>