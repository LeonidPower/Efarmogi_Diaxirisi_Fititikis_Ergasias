<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../assets/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark top-nav-color">
            <a class="navbar-brand ps-3" href="../commons/dashboard.php">Ordinatio Garden Industry</a>
        <div class="container-fluid align-list-right">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle mt-1" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw fa-xl" ></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><form class="dropdown-item text-center" name="logout" action="../commons/logout.php" method="POST">
                            <button class="log-out-btn" type="submit">Logout</button>
                        </form></li>
                    </ul>
                </li>
                <div class="ms-4">
                    <div class="small">Logged in as: <?php echo ucfirst($_SESSION['name']); ?></div>
                    <?php
                        
                        # Display everything in session
                        error_log("Session: " . print_r($_SESSION, true));
                        if ($_SESSION['position'] == '3' ){ 
                            echo "<p class='text-light'>Role: Admin</p>";
                        }elseif($_SESSION['position'] == '2'){ 
                            echo "<p class='text-light'>Role: Administrative service management</p>";
                        }
                        elseif($_SESSION['position'] == '1'){ 
                            echo "<p class='text-light'>Role: Student Employee</p>";
                        }else{
                            error_log("Error: User position not found, logging out.");
                            include "../commons/logout.php";
                        }
                    ?>
                </div>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-color" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav mt-3">
                        <a class="nav-link" href="../commons/dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <?php
                            if ( $_SESSION['position'] == '3'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUsers" aria-expanded="false" aria-controls="collapseUsers">
                                        <div class="sb-nav-link-icon"><i class="bi bi-people-fill"></i></div>
                                            Manage Employees
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseUsers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['position'] == '3'){      
                                            echo '<a class="nav-link" href="../admin/employee.php">View All Employees</a>';
                                        }
                                        if ( $_SESSION['position'] == '3'){      
                                            echo '<a class="nav-link" href="../admin/employee_form.php">Add New Employee</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['position'] == '3'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseServices" aria-expanded="false" aria-controls="collapseServices">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-hand-holding"></i></div>
                                            Manage Services
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>
                                    <div class="collapse" id="collapseServices" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav">';
                                        if ( $_SESSION['position'] == '3'){      
                                            echo '<a class="nav-link" href="../admin/services.php">View Services</a>';
                                        }
                                        if ( $_SESSION['position'] == '3'){      
                                            echo '<a class="nav-link" href="../admin/employee_form.php">Add New Service</a>';
                                        }
                                        
                                echo  '</nav>
                                    </div>';
                            }
                        ?>
                        <?php
                            if ( $_SESSION['position'] == '3'){      

                                echo '<a class="nav-link" href="../admin/sysconfigs.php">
                                        <div class="sb-nav-link-icon"><i class="fa-solid fa-gear"></i></div>
                                            Configure System
                                    </a>';
                                    
                            }
                        ?>
                        <?php
                            if ( $_SESSION['position'] == '3'){      

                                echo '<a class="nav-link collapsed" href="#" data-bs-toggle="collapse" aria-expanded="false">
                                        <div class="sb-nav-link-icon"><i class="bi bi-people-fill"></i></div>
                                            Report
                                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                    </a>';
                            }
                            if (isset($_SESSION['message'])) {
                                echo '<div class="alert alert-success" role="alert">' . $_SESSION['message'] . '</div>';
                                unset($_SESSION['message']);
                            }
                        ?>
                    </div>
            </nav>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    </body>
</html>